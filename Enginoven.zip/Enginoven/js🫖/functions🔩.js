function createDiv(divId = BLANK_STR, divWidth = 200,divHeight = 100, divBg = 'grey'){
    let newDiv = document.createElement('div');
    newDiv.id = divId;
    newDiv.style.width = `${divWidth}${styleUnit}`;
    newDiv.style.height = `${divHeight}${styleUnit}`;
    newDiv.style.backgroundColor = divBg;

    return newDiv
  }

  function createBtn(btnId = BLANK_STR, btnWidth = 50,btnHeight = 30, btnBg = 'beige', btnText ='btn'){
    let newBtn = document.createElement('button');
    newBtn.id = btnId;
    newBtn.innerText = btnText;
    newBtn.style.width = `${btnWidth}${styleUnit}`;
    newBtn.style.height = `${btnHeight}${styleUnit}`;
    newBtn.style.backgroundColor = btnBg;

    return newBtn
  }
 
  function createTxtInput(txtInputId = BLANK_STR, txtInputPlaceholder = 'game name'){
    let newTxtInput = document.createElement('input');
    newTxtInput.id = txtInputId;
    newTxtInput.setAttribute('type','text');
    newTxtInput.setAttribute('placeholder',txtInputPlaceholder);
    newTxtInput.style.width = `290${styleUnit}`;
    newTxtInput.style.height = `40${styleUnit}`;
    newTxtInput.style.fontSize = `18${styleUnit}`;
    newTxtInput.style.backgroundColor = '#F2F597';
    newTxtInput.style.color = '#0A1D56';

    return newTxtInput
  }

  function openLink(pageLink = 'https://example.com', targetType = '_blank'){
        window.open(pageLink, target = targetType);
  }

  function generateLink(theArray = [], theSearchText = defaultSearchText){ // generate link from Array
    let link = BLANK_STR;

    for (let i of theArray){
  
        if ( (typeof i) === 'string' ){
            link += theSearchText;
        }
        else if ( (typeof i) === 'object' ){
            link += i;
        }
    }

    return link;
  }

