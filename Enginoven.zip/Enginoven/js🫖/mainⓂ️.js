window.onload = function(){
  makeApp();
}

function makeApp(){
  loadLinks();
  appName = new AppName();
  body = document.querySelector('body');
  appName.onAppStart();
}

function loadLinks(){
  links = {
    "translation": [
       ["French", "🇫🇷", "fr"],
       ["Italian", "🇮🇹", "it"],
       ["Spanish", "🇪🇸", "es"],
    ],
    "google":[
        ['Google Text', '📘', [  ["https://www.google.com/search?&q="] , SEARCH_PLACE  ] ],
        ['Google images', '🖼️', [ ["https://www.google.com/search?&q="], SEARCH_PLACE, ["&tbm=isch"]  ] ]
    
    ],
    "prompts": [
      [
        'YouChat',
        '🗨️',
        [ ["https://you.com/search?q=Try guess the subject of a fictional video game by it's name \""], SEARCH_PLACE , ["\"&fromSearchBar=true&tbm=youchat"] ] 
      ]
    ],
    "synonyms":[
      ['Thesaurus','🟧', [ ["https://www.thesaurus.com/browse/"], SEARCH_PLACE] ],
      ['Synonyms','🟩',[ ["https://www.synonyms.com/synonym/"], SEARCH_PLACE] ]
    ]
  }
}
