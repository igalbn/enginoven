function AppName(){

    let self = this;
    self.buttonsAreaHeight = 40;
    self.buttonsMargin = 5;
    self.defaultBg = '#37B5B6';

    self.onAppStart = () => {  
        self.makeTags();
    }

    self.makeTags = () => {
        myApp = createDiv('my_app', 302,208, 'None');
        body.appendChild(myApp);
        
        self.makeInput();
        self.makeTranslation();
        self.makeGoogle();
        self.makePrompts();
        self.makeSynonyms();
    }

    self.makeInput = () => {
        self.nameTxtInput = createTxtInput();
        
        myApp.appendChild(self.nameTxtInput);
        let newBr = document.createElement('br');
        myApp.appendChild(newBr);
    }

    self.makeTranslation = () => {
        // make translation area
        let translationDiv = createDiv('translation_div', 300, self.buttonsAreaHeight, self.defaultBg);
        myApp.appendChild(translationDiv);
        
        // make translations buttons
        for (let i of links.translation){
      
          let translationBtnText = `${i[0]} ${i[1]}`;
          let translationBtn = createBtn(BLANK_STR,100,30, 'beige', translationBtnText);

          translationBtn.onclick = () => {
            
            let searchText = (self.nameTxtInput.value !== BLANK_STR) ? self.nameTxtInput.value : 'video game';
            openLink(`https://translate.google.com/?sl=en&tl=${i[2]}&text=${searchText}&op=translate`);
            
          }

          translationDiv.appendChild(translationBtn);
        }
    }

    self.makeGoogle = () => {
        // make google area
        let googleDiv = createDiv('google_div', 300, self.buttonsAreaHeight, self.defaultBg);
        myApp.appendChild(googleDiv);

        // make translations buttons
        for (let i of links.google){
            let googleBtnText = `${i[0]} ${i[1]}`;
            let googleBtn = createBtn(BLANK_STR,150,30, 'beige', googleBtnText);
    
            googleBtn.onclick = () => {    
                // let searchText = self.provideSearchText();
                let googleLink = generateLink(i[2], self.provideSearchText());
                openLink(googleLink);
                
            }
    
            googleDiv.appendChild(googleBtn);
            }
    }

    self.makePrompts = () => {
        // make prompts area
        let googleDiv = createDiv('prompts_div', 300, self.buttonsAreaHeight, self.defaultBg);
        myApp.appendChild(googleDiv);

        // make translations buttons
        for (let i of links.prompts){
            let promptsBtnText = `${i[0]} ${i[1]}`;
            let promptsBtn = createBtn(BLANK_STR,150,30, 'beige', promptsBtnText);
    
            promptsBtn.onclick = () => {
                let promptLink = generateLink(i[2], self.provideSearchText());
                openLink(promptLink);
            }
    
            googleDiv.appendChild(promptsBtn);
            }
    }
    self.makeSynonyms = () => {
        // make google area
        let synonymsDiv = createDiv('synonyms_div', 300, self.buttonsAreaHeight, self.defaultBg);
        myApp.appendChild(synonymsDiv);

        // make translations buttons
        for (let i of links.synonyms){
            let synonymsBtnText = `${i[0]} ${i[1]}`;
            let synonymsBtn = createBtn(BLANK_STR,150,30, 'beige', synonymsBtnText);

            synonymsBtn.onclick = () => {    
               
                let synonymsLink = generateLink(i[2], self.provideSearchText());
                openLink(synonymsLink);
                
            }
    
            synonymsDiv.appendChild(synonymsBtn);
            }
    }

    self.provideSearchText = () => {
        let searchText = (self.nameTxtInput.value !== BLANK_STR) ? self.nameTxtInput.value : 'video game';
        return searchText
      }
}