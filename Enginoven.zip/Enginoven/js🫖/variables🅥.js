let BLANK_STR = '';
let body,myApp;

let styleUnit = 'px';
let links;
let defaultSearchText = 'video game';

const SEARCH_PLACE = "SEARCH_PLACE";// place of search query in a link
